c11Mc12 = 67.0
c44 = 68.0
B = 102.5

c11 = (3.*B+2.*c11Mc12)/3.
c12 = -1.*(c11Mc12-c11)

Gv = 0.2*(c11Mc12+3.*c44)
Gr = 5.*(c11Mc12)*c44/(4.*c44+3.*c11Mc12)

Ev = 9.*Gv*B/(3.*B+Gv)
Er = 9.*Gr*B/(3.*B+Gr)

E100 = (c11-c12)*(c11+2*c12)/(c11+c12)
E110 = 4.*(c11-c12)*(c11+2.*c12)*c44/(2*c11*c44 + (c11-c12)*(c11+2.*c12))
E111 = 3.*(c11+2.*c12)*c44/(c11+2.*c12+c44)

k = (Gv+Gr)/(2.*B)
HvPoly = 2.*(k*k*0.5*(Gv+Gr))**0.585-3.
HvBrittle = 0.151*0.5*(Gv+Gr)

print "c11,c12,c44,Ev,Er,0.95*0.5*(Ev+Er)"
print c11, c12, c44, Ev, Er,0.95*0.5*(Ev+Er)

print "E100 = ", E100
print "E110 = ", E110
print "E111 = ", E111

print "k = G/B = ", k

print "Hv poly = ", HvPoly

print "Hv brittle = ", HvBrittle

exit(1)
 
