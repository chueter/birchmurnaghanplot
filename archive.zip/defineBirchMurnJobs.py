import re
import os
import sys
import math

i=0


while i < 7:
    delta = 1.+(-0.03+i*0.01)
    os.system('echo ' + str(delta))
    os.system('mkdir delta=' + str(delta))
    os.system('cp POSCAR POSCAR' + str(i))


    with open("POSCAR", "rt") as fin:
        with open("POSCAR"+str(i), "wt") as fout:
            for line in fin:
                fout.write(line.replace('1.0', str(delta)))

    os.system('cp {INCAR,KPOINTS,POTCAR} delta=' + str(delta) + '/.')
    os.system('cp POSCAR'+ str(i) +' delta=' + str(delta) + '/POSCAR')
    os.system('rm POSCAR'+ str(i))
    i = i+1

exit(1)

