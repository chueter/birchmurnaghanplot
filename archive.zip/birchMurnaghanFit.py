#!/usr/bin/env python
import numpy as np
from ase.io import read
from ase.units import kJ
from ase.eos import EquationOfState

EvsLattconst = np.loadtxt("E0vsA")
volumes = []
energies = []

for dataPoint in EvsLattconst:
    volumes.append(dataPoint[0]**3.)
    energies.append(dataPoint[1])



eos = EquationOfState(volumes, energies, eos='birchmurnaghan')
#, eos='murnaghan'
#, eos='birchmurnaghan'
v0, e0, B = eos.fit()
print(B / kJ * 1.0e24, 'GPa')
print "a_0 = ", v0**0.3333
eos.plot()

exit(1)


'''
a=12.9805
p97=np.loadtxt("delta=0.97/pos")*a
p98=np.loadtxt("delta=0.98/pos")*a
p99=np.loadtxt("delta=0.99/pos")*a
p100=np.loadtxt("delta=1.0/pos")*a
'''


'''
    from ase.build import bulk
    >>> from ase.calculators.emt import EMT
    >>> a = bulk('Cu', 'fcc', a=3.6)
    >>> a.calc = EMT()
    >>> eos = calculate_eos(a, trajectory='Cu.traj')
    >>> v, e, B = eos.fit()
    >>> a = (4 * v)**(1 / 3.0)
    >>> print('{0:.6f}'.format(a))
'''
